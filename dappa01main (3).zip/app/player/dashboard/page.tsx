"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useSupabase } from "@/components/providers/supabase-provider"
import { Trophy, Users, Calendar, Award, Activity } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"

interface Match {
  id: string
  team_a: string
  team_b: string
  date: string
  time: string
  venue: string
  score_team_a: number | null
  score_team_b: number | null
  status: string
}

interface Tournament {
  id: string
  name: string
  start_date: string
  end_date: string
  status: string
}

interface Achievement {
  id: string
  title: string
  tournament: string
  date: string
}
interface DashboardCounts {
  activePlayers: number
  activeTournaments: number
  upcomingMatches: number
}

export default function PlayerDashboardPage() {
  const { supabase, user } = useSupabase()
  const [profile, setProfile] = useState<any>(null)
  const [upcomingMatches, setUpcomingMatches] = useState<Match[]>([])
  const [activeTournaments, setActiveTournaments] = useState<Tournament[]>([])
  const [achievements, setAchievements] = useState<Achievement[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()
  const [counts, setCounts] = useState<DashboardCounts>({
    activePlayers: 0,
    activeTournaments: 0,
    upcomingMatches: 0,
  })
  useEffect(() => {
    if (!user) {
      window.location.href = "/login"
      return
    }
    fetchPlayerData()
  }, [user])
  const fetchDashboardData = async () => {
    setLoading(true)
    try {
      // // Fetch pending players
      // const { data: pendingPlayersData, error: pendingPlayersError } = await supabase
      //   .from("profiles")
      //   .select("*")
      //   .eq("status", "pending")
      //   .eq("user_type", "player")

      // Fetch active players count
      const { count: activePlayersCount, error: activePlayersError } = await supabase
        .from("profiles")
        .select("*", { count: "exact", head: true })
        .eq("status", "approved")
        .eq("user_type", "player")

      if (activePlayersError) throw activePlayersError

      // Fetch active tournaments count
      const { count: activeTournamentsCount, error: tournamentsError } = await supabase
        .from("tournaments")
        .select("*", { count: "exact", head: true })
        .eq("status", "active")

      if (tournamentsError) throw tournamentsError

      // Fetch upcoming matches count
      const { count: upcomingMatchesCount, error: matchesError } = await supabase
        .from("matches")
        .select("*", { count: "exact", head: true })
        .eq("status", "scheduled")

      if (matchesError) throw matchesError

      setCounts({
        activePlayers: activePlayersCount || 0,
        activeTournaments: activeTournamentsCount || 0,
        upcomingMatches: upcomingMatchesCount || 0,
      })
    } catch (error: any) {
      console.error("Error fetching dashboard data:", error)
      toast({
        title: "Error fetching dashboard data",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }
  const fetchPlayerData = async () => {
    setLoading(true)
    try {
      // Fetch player profile
      const { data: profileData, error: profileError } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user?.id)
        .single()

      if (profileError) throw profileError
      setProfile(profileData)

      // Fetch upcoming matches
      const { data: matchesData, error: matchesError } = await supabase
        .from("matches")
        .select("*")
        .gt("date", new Date().toISOString())
        .order("date", { ascending: true })
        .limit(5)

      if (matchesError) throw matchesError
      setUpcomingMatches(matchesData || [])

      // Fetch active tournaments
      const { data: tournamentsData, error: tournamentsError } = await supabase
        .from("tournaments")
        .select("*")
        .eq("status", "active")
        .order("start_date", { ascending: true })
        .limit(3)

      if (tournamentsError) throw tournamentsError
      setActiveTournaments(tournamentsData || [])

      // Fetch player achievements
      const { data: achievementsData, error: achievementsError } = await supabase
        .from("achievements")
        .select("*")
        .eq("player_id", user?.id)
        .order("date", { ascending: false })
        .limit(5)

      if (achievementsError) throw achievementsError
      setAchievements(achievementsData || [])
    } catch (error) {
      console.error("Error fetching player data:", error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Player Dashboard</h1>

      {profile && (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">My Rating</CardTitle>
              <Trophy className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{profile.rating || "N/A"}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Team Players</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{counts.activePlayers}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Upcoming Matches</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{upcomingMatches.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Achievements</CardTitle>
              <Award className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{achievements.length}</div>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="mr-2 h-5 w-5" />
              Upcoming Matches
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Teams</TableHead>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>Venue</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {upcomingMatches.length > 0 ? (
                  upcomingMatches.map((match) => (
                    <TableRow key={match.id}>
                      <TableCell className="font-medium">
                        {match.team_a} vs {match.team_b}
                      </TableCell>
                      <TableCell>
                        {new Date(match.date).toLocaleDateString()} {match.time}
                      </TableCell>
                      <TableCell>{match.venue}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center">
                      No upcoming matches
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Trophy className="mr-2 h-5 w-5" />
              Active Tournaments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Start Date</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activeTournaments.length > 0 ? (
                  activeTournaments.map((tournament) => (
                    <TableRow key={tournament.id}>
                      <TableCell className="font-medium">{tournament.name}</TableCell>
                      <TableCell>{new Date(tournament.start_date).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
                          {tournament.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center">
                      No active tournaments
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Award className="mr-2 h-5 w-5" />
              My Achievements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Achievement</TableHead>
                  <TableHead>Tournament</TableHead>
                  <TableHead>Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {achievements.length > 0 ? (
                  achievements.map((achievement) => (
                    <TableRow key={achievement.id}>
                      <TableCell className="font-medium">{achievement.title}</TableCell>
                      <TableCell>{achievement.tournament}</TableCell>
                      <TableCell>{new Date(achievement.date).toLocaleDateString()}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center">
                      No achievements yet
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="mr-2 h-5 w-5" />
              Live Matches
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Teams</TableHead>
                  <TableHead>Score</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">Team A vs Team B</TableCell>
                  <TableCell className="font-bold">2 - 1</TableCell>
                  <TableCell>
                    <Badge className="bg-red-100 text-red-800 hover:bg-red-100">LIVE</Badge>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Team C vs Team D</TableCell>
                  <TableCell className="font-bold">0 - 0</TableCell>
                  <TableCell>
                    <Badge className="bg-red-100 text-red-800 hover:bg-red-100">LIVE</Badge>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell colSpan={3} className="text-center text-sm text-muted-foreground">
                    Click on a match to view detailed live updates
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}


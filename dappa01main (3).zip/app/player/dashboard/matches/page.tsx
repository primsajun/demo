"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "@/components/providers/supabase-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/components/ui/use-toast"
import { Calendar, FileText } from "lucide-react"

interface Match {
  id: string
  team_a: string
  team_b: string
  date: string
  time: string
  venue: string
  tournament_id: string
  score_team_a: number | null
  score_team_b: number | null
  status: string
}

interface Tournament {
  id: string
  name: string
}

export default function MatchesPage() {
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const router = useRouter()
  const [matches, setMatches] = useState<Match[]>([])
  const [tournaments, setTournaments] = useState<Tournament[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)

  // Form state
  const [teamA, setTeamA] = useState("")
  const [teamB, setTeamB] = useState("")
  const [date, setDate] = useState("")
  const [time, setTime] = useState("")
  const [venue, setVenue] = useState("")
  const [tournamentId, setTournamentId] = useState("")
  const [scoreTeamA, setScoreTeamA] = useState("")
  const [scoreTeamB, setScoreTeamB] = useState("")
  const [status, setStatus] = useState("scheduled")

  useEffect(() => {
    fetchMatches()
    fetchTournaments()
  }, [])

  const fetchMatches = async () => {
    setLoading(true)
    const { data, error } = await supabase.from("matches").select("*").order("date", { ascending: true })

    if (error) {
      toast({
        title: "Error fetching matches",
        description: error.message,
        variant: "destructive",
      })
    } else {
      setMatches(data || [])
    }
    setLoading(false)
  }

  const fetchTournaments = async () => {
    const { data, error } = await supabase.from("tournaments").select("id, name")

    if (error) {
      toast({
        title: "Error fetching tournaments",
        description: error.message,
        variant: "destructive",
      })
    } else {
      setTournaments(data || [])
    }
  }

  const resetForm = () => {
    setTeamA("")
    setTeamB("")
    setDate("")
    setTime("")
    setVenue("")
    setTournamentId("")
    setScoreTeamA("")
    setScoreTeamB("")
    setStatus("scheduled")
    setEditingId(null)
    setShowForm(false)
  }

  const handleEdit = (match: Match) => {
    setTeamA(match.team_a)
    setTeamB(match.team_b)
    setDate(match.date.split("T")[0])
    setTime(match.time)
    setVenue(match.venue)
    setTournamentId(match.tournament_id)
    setScoreTeamA(match.score_team_a?.toString() || "")
    setScoreTeamB(match.score_team_b?.toString() || "")
    setStatus(match.status)
    setEditingId(match.id)
    setShowForm(true)
  }

  const handleViewSummary = (id: string) => {
    router.push(`/player/dashboard/match-summary/${id}`)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const matchData = {
      team_a: teamA,
      team_b: teamB,
      date,
      time,
      venue,
      tournament_id: tournamentId,
      score_team_a: scoreTeamA ? Number.parseInt(scoreTeamA) : null,
      score_team_b: scoreTeamB ? Number.parseInt(scoreTeamB) : null,
      status,
      teams: [teamA, teamB],
    }

    if (editingId) {
      // Update existing match
      const { error } = await supabase.from("matches").update(matchData).eq("id", editingId)

      if (error) {
        toast({
          title: "Error updating match",
          description: error.message,
          variant: "destructive",
        })
      } else {
        toast({
          title: "Match updated",
          description: "The match has been updated successfully",
        })
        resetForm()
        fetchMatches()
      }
    } else {
      // Create new match
      const { error } = await supabase.from("matches").insert([matchData])
      console.log(error)
      if (error) {
        toast({
          title: "Error creating match",
          description: error.message,
          variant: "destructive",
        })
      } else {
        toast({
          title: "Match created",
          description: "The match has been created successfully",
        })
        resetForm()
        fetchMatches()
      }
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Matches</h1>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>{editingId ? "Edit Match" : "Add Match"}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="teamA">Team A</Label>
                  <Input id="teamA" value={teamA} onChange={(e) => setTeamA(e.target.value)} required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="teamB">Team B</Label>
                  <Input id="teamB" value={teamB} onChange={(e) => setTeamB(e.target.value)} required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="time">Time</Label>
                  <Input id="time" type="time" value={time} onChange={(e) => setTime(e.target.value)} required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="venue">Venue</Label>
                  <Input id="venue" value={venue} onChange={(e) => setVenue(e.target.value)} required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tournament">Tournament</Label>
                  <select
                    id="tournament"
                    value={tournamentId}
                    onChange={(e) => setTournamentId(e.target.value)}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    required
                  >
                    <option value="">Select Tournament</option>
                    {tournaments.map((tournament) => (
                      <option key={tournament.id} value={tournament.id}>
                        {tournament.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="scoreTeamA">Score Team A</Label>
                  <Input
                    id="scoreTeamA"
                    type="number"
                    value={scoreTeamA}
                    onChange={(e) => setScoreTeamA(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="scoreTeamB">Score Team B</Label>
                  <Input
                    id="scoreTeamB"
                    type="number"
                    value={scoreTeamB}
                    onChange={(e) => setScoreTeamB(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <select
                    id="status"
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    required
                  >
                    <option value="scheduled">Scheduled</option>
                    <option value="live">Live</option>
                    <option value="completed">Completed</option>
                    <option value="postponed">Postponed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
                <Button type="submit">{editingId ? "Update Match" : "Create Match"}</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Calendar className="mr-2 h-5 w-5" />
            All Matches
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center p-4">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Teams</TableHead>
                  <TableHead>Date & Time </TableHead>
                  <TableHead>Venue</TableHead>
                  <TableHead>Score</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {matches.length > 0 ? (
                  matches.map((match) => (
                    <TableRow key={match.id}>
                      <TableCell className="font-medium">
                        {match.team_a} vs {match.team_b}
                      </TableCell>
                      <TableCell>
                        {new Date(match.date).toLocaleDateString()} {match.time}
                      </TableCell>
                      <TableCell>{match.venue}</TableCell>
                      <TableCell>
                        {match.score_team_a !== null && match.score_team_b !== null
                          ? `${match.score_team_a} - ${match.score_team_b}`
                          : "Not played"}
                      </TableCell>
                      <TableCell>
                        <span
                          className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                            match.status === "live"
                              ? "bg-green-100 text-green-800"
                              : match.status === "scheduled"
                                ? "bg-blue-100 text-blue-800"
                                : match.status === "completed"
                                  ? "bg-gray-100 text-gray-800"
                                  : "bg-red-100 text-red-800"
                          }`}
                        >
                          {match.status.charAt(0).toUpperCase() + match.status.slice(1)}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleViewSummary(match.id)}
                          className="flex items-center gap-1"
                        >
                          <FileText className="h-4 w-4 mr-1" />
                          Summary
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center">
                      No matches found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}


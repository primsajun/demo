"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useSupabase } from "@/components/providers/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"

interface Player {
  id: string
  name: string
  email: string
  position: string
  jersey_number: number
  rating: number
}

export default function TeamPlayersPage() {
  const { supabase, user } = useSupabase()
  const { toast } = useToast()
  const [players, setPlayers] = useState<Player[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [userTeam, setUserTeam] = useState<string | null>(null)

  useEffect(() => {
    if (user) {
      fetchUserTeam()
    }
  }, [user])

  useEffect(() => {
    if (userTeam) {
      fetchTeamPlayers()
    }
  }, [userTeam])

  const fetchUserTeam = async () => {
    try {
      const { data, error } = await supabase.from("profiles").select("team").eq("id", user?.id).single()

      if (error) {
        throw error
      }

      setUserTeam(data.team)
    } catch (error: any) {
      console.error("Error fetching user team:", error)
      toast({
        title: "Error",
        description: "Failed to load your team information",
        variant: "destructive",
      })
    }
  }

  const fetchTeamPlayers = async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, name, email, position, jersey_number, rating")
        .eq("team", userTeam)
        .eq("status", "approved")
        .order("name")

      if (error) {
        throw error
      }

      setPlayers(data || [])
    } catch (error: any) {
      console.error("Error fetching team players:", JSON.stringify(error, null, 2))
      toast({
        title: "Error",
        description: "Failed to load team players",
      })
    } finally {
      setLoading(false)
    }
  }

  const filteredPlayers = players.filter(
    (player) =>
      player.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      player.position?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  if (loading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Team Players</h1>

      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Search players by name or position..."
          className="pl-9 w-full"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {!userTeam ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6">
            <p className="text-center text-muted-foreground">You are not assigned to any team yet.</p>
          </CardContent>
        </Card>
      ) : filteredPlayers.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6">
            <p className="text-center text-muted-foreground">No players found in your team.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredPlayers.map((player) => (
            <Card key={player.id}>
              <CardHeader className="pb-2">
                <div className="flex items-center space-x-4">
                  <Avatar>
                    <AvatarImage src="/placeholder-user.jpg" alt={player.name} />
                    <AvatarFallback>{player.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-lg">{player.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">{player.email}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">Position</span>
                    <span className="font-medium">{player.position || "Not set"}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">Jersey #</span>
                    <span className="font-medium">{player.jersey_number || "N/A"}</span>
                  </div>
                  <div className="flex flex-col col-span-2 mt-2">
                    <span className="text-muted-foreground">Rating</span>
                    <div className="flex items-center mt-1">
                      <div
                        className="h-2 bg-primary rounded-full"
                        style={{ width: `${(player.rating || 0) * 10}%` }}
                      ></div>
                      <span className="ml-2 text-sm font-medium">{player.rating || 0}/10</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}


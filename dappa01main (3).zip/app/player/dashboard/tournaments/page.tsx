"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useSupabase } from "@/components/providers/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { Calendar, MapPin, Trophy } from "lucide-react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

interface Tournament {
  id: string
  name: string
  start_date: string
  end_date: string
  location: string
  status: string
  description: string
}

export default function PlayerTournamentsPage() {
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [tournaments, setTournaments] = useState<Tournament[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedTournament, setSelectedTournament] = useState<Tournament | null>(null)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)

  useEffect(() => {
    fetchTournaments()
  }, [])

  const fetchTournaments = async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase.from("tournaments").select("*").order("start_date", { ascending: false })

      if (error) {
        throw error
      }

      setTournaments(data || [])
    } catch (error: any) {
      console.error("Error fetching tournaments:", error)
      toast({
        title: "Error fetching tournaments",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleViewDetails = (tournament: Tournament) => {
    setSelectedTournament(tournament)
    setIsDetailsOpen(true)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-100 text-green-800">Active</Badge>
      case "upcoming":
        return <Badge className="bg-blue-100 text-blue-800">Upcoming</Badge>
      case "completed":
        return <Badge className="bg-gray-100 text-gray-800">Completed</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  if (loading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Tournaments</h1>

      {tournaments.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6">
            <Trophy className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-center text-muted-foreground">No tournaments available at the moment.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {tournaments.map((tournament) => (
            <Card key={tournament.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-xl">{tournament.name}</CardTitle>
                  {getStatusBadge(tournament.status)}
                </div>
                <CardDescription>
                  {new Date(tournament.start_date).toLocaleDateString()} -{" "}
                  {new Date(tournament.end_date).toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="space-y-2 text-sm">
                  {tournament.location && (
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{tournament.location}</span>
                    </div>
                  )}
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>
                      {Math.ceil(
                        (new Date(tournament.end_date).getTime() - new Date(tournament.start_date).getTime()) /
                          (1000 * 60 * 60 * 24),
                      )}{" "}
                      days
                    </span>
                  </div>
                  {/* <div className="flex items-center">
                    <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>16 teams</span>
                  </div> */}
                </div>
              </CardContent>
              {/* <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => handleViewDetails(tournament)}>
                  View Details
                </Button>
              </CardFooter> */}
            </Card>
          ))}
        </div>
      )}

      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{selectedTournament?.name}</DialogTitle>
            <DialogDescription>
              {selectedTournament && (
                <>
                  {new Date(selectedTournament.start_date).toLocaleDateString()} -{" "}
                  {new Date(selectedTournament.end_date).toLocaleDateString()}
                </>
              )}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex justify-between">
              <div className="flex items-center">
                <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                <span>{selectedTournament?.location || "Location not specified"}</span>
              </div>
              <div>{selectedTournament && getStatusBadge(selectedTournament.status)}</div>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Description</h4>
              <p className="text-sm text-muted-foreground">
                {selectedTournament?.description || "No description available."}
              </p>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Teams</h4>
              <div className="grid grid-cols-2 gap-2">
                <div className="rounded-md border p-2 text-center text-sm">Team A</div>
                <div className="rounded-md border p-2 text-center text-sm">Team B</div>
                <div className="rounded-md border p-2 text-center text-sm">Team C</div>
                <div className="rounded-md border p-2 text-center text-sm">Team D</div>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Upcoming Matches</h4>
              <div className="space-y-2">
                <div className="rounded-md border p-2 text-sm">
                  <div className="font-medium">Team A vs Team B</div>
                  <div className="text-xs text-muted-foreground">Tomorrow, 15:00 • Stadium 1</div>
                </div>
                <div className="rounded-md border p-2 text-sm">
                  <div className="font-medium">Team C vs Team D</div>
                  <div className="text-xs text-muted-foreground">May 15, 2023, 18:00 • Stadium 2</div>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}


"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "@/components/providers/supabase-provider"
import { AdminSidebarNav } from "@/components/admin/sidebar-nav"
import { SidebarProvider } from "@/components/ui/sidebar"

export default function AdminDashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { user, loading, supabase } = useSupabase()
  const router = useRouter()
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null)

  useEffect(() => {
    const checkAdminAccess = async () => {
      if (!loading) {
        if (!user) {
          router.push("/login")
          return
        }

        if (user) {
          try {
            const { data: profile, error } = await supabase
              .from("profiles")
              .select("user_type")
              .eq("id", user.id)
              .single()

            if (error) {
              console.error("Error fetching profile:", error)
              setIsAdmin(false)
              router.push("/login")
              return
            }

            if (profile?.user_type !== "admin") {
              setIsAdmin(false)
              router.push("/login")
              return
            }

            setIsAdmin(true)
          } catch (error) {
            console.error("Error in admin access check:", error)
            setIsAdmin(false)
            router.push("/login")
          }
        }
      }
    }

    if (supabase) {
      checkAdminAccess()
    }
  }, [user, loading, router, supabase])

  if (loading || isAdmin === null) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
      </div>
    )
  }

  if (isAdmin === false) {
    return null // Or redirect, or render an error message
  }

  return (
    <div className="flex min-h-screen flex-col">
      <div className="football-bg"></div>
      <SidebarProvider>
        <div className="flex flex-1">
          <AdminSidebarNav />
          <main className="flex-1 p-6 md:p-8">
            <div className="flex-1 md:ml-0 pt-14 md:pt-0">{children}</div>
          </main>
        </div>
      </SidebarProvider>
    </div>
  )
}


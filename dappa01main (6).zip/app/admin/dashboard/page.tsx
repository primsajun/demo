"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useSupabase } from "@/components/providers/supabase-provider"
import { Trophy, Users, Calendar, UserCheck, UserX } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { useRouter } from "next/navigation"

interface Player {
  id: string
  name: string
  email: string
  phone: string
  status: string
}

interface DashboardCounts {
  pendingApprovals: number
  activePlayers: number
  activeTournaments: number
  upcomingMatches: number
}

export default function AdminDashboardPage() {
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const router = useRouter()
  const [pendingPlayers, setPendingPlayers] = useState<Player[]>([])
  const [counts, setCounts] = useState<DashboardCounts>({
    pendingApprovals: 0,
    activePlayers: 0,
    activeTournaments: 0,
    upcomingMatches: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    setLoading(true)
    try {
      // Fetch pending players
      const { data: pendingPlayersData, error: pendingPlayersError } = await supabase
        .from("profiles")
        .select("*")
        .eq("status", "pending")
        .eq("user_type", "player")

      if (pendingPlayersError) throw pendingPlayersError
      setPendingPlayers(pendingPlayersData || [])

      // Fetch active players count
      const { count: activePlayersCount, error: activePlayersError } = await supabase
        .from("profiles")
        .select("*", { count: "exact", head: true })
        .eq("status", "approved")
        .eq("user_type", "player")

      if (activePlayersError) throw activePlayersError

      // Fetch active tournaments count
      const { count: activeTournamentsCount, error: tournamentsError } = await supabase
        .from("tournaments")
        .select("*", { count: "exact", head: true })
        .eq("status", "active")

      if (tournamentsError) throw tournamentsError

      // Fetch upcoming matches count
      const { count: upcomingMatchesCount, error: matchesError } = await supabase
        .from("matches")
        .select("*", { count: "exact", head: true })
        .eq("status", "scheduled")

      if (matchesError) throw matchesError

      setCounts({
        pendingApprovals: pendingPlayersData?.length || 0,
        activePlayers: activePlayersCount || 0,
        activeTournaments: activeTournamentsCount || 0,
        upcomingMatches: upcomingMatchesCount || 0,
      })
    } catch (error: any) {
      console.error("Error fetching dashboard data:", error)
      toast({
        title: "Error fetching dashboard data",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleApprovePlayer = async (playerId: string) => {
    try {
      const { error } = await supabase.from("profiles").update({ status: "approved" }).eq("id", playerId)

      if (error) {
        throw error
      }

      toast({
        title: "Player approved",
        description: "The player has been approved successfully",
      })

      // Update the local state
      setPendingPlayers(pendingPlayers.filter((player) => player.id !== playerId))
      setCounts((prev) => ({
        ...prev,
        pendingApprovals: prev.pendingApprovals - 1,
        activePlayers: prev.activePlayers + 1,
      }))
    } catch (error: any) {
      toast({
        title: "Error approving player",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const handleRejectPlayer = async (playerId: string) => {
    try {
      const { error } = await supabase.from("profiles").update({ status: "rejected" }).eq("id", playerId)

      if (error) {
        throw error
      }

      toast({
        title: "Player rejected",
        description: "The player has been rejected",
      })

      // Update the local state
      setPendingPlayers(pendingPlayers.filter((player) => player.id !== playerId))
      setCounts((prev) => ({
        ...prev,
        pendingApprovals: prev.pendingApprovals - 1,
      }))
    } catch (error: any) {
      toast({
        title: "Error rejecting player",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const navigateToSection = (path: string) => {
    router.push(path)
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Admin Dashboard</h1>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => navigateToSection("/admin/dashboard/approvals")}
        >
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{counts.pendingApprovals}</div>
          </CardContent>
        </Card>

        <Card
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => navigateToSection("/admin/dashboard/players")}
        >
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Players</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{counts.activePlayers}</div>
          </CardContent>
        </Card>

        <Card
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => navigateToSection("/admin/dashboard/tournaments")}
        >
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Tournaments</CardTitle>
            <Trophy className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{counts.activeTournaments}</div>
          </CardContent>
        </Card>

        <Card
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => navigateToSection("/admin/dashboard/matches")}
        >
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Matches</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{counts.upcomingMatches}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <UserCheck className="mr-2 h-5 w-5" />
            Pending Player Approvals
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center p-4">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingPlayers.length > 0 ? (
                  pendingPlayers.map((player) => (
                    <TableRow key={player.id}>
                      <TableCell className="font-medium">{player.name}</TableCell>
                      <TableCell>{player.email}</TableCell>
                      <TableCell>{player.phone}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
                          Pending
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          className="mr-2 bg-green-100 text-green-800 hover:bg-green-200"
                          onClick={() => handleApprovePlayer(player.id)}
                        >
                          <UserCheck className="mr-1 h-4 w-4" />
                          Approve
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="bg-red-100 text-red-800 hover:bg-red-200"
                          onClick={() => handleRejectPlayer(player.id)}
                        >
                          <UserX className="mr-1 h-4 w-4" />
                          Reject
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center">
                      No pending player approvals
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}


"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useSupabase } from "@/components/providers/supabase-provider"
import { UserCheck, UserX } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"

interface Player {
  id: string
  name: string
  email: string
  phone: string
  status: string
}

export default function PlayerApprovalsPage() {
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [pendingPlayers, setPendingPlayers] = useState<Player[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchPendingPlayers()
  }, [])

  const fetchPendingPlayers = async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("status", "pending")
        .eq("user_type", "player")

      if (error) {
        throw error
      }

      setPendingPlayers(data || [])
    } catch (error: any) {
      toast({
        title: "Error fetching pending players",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleApprovePlayer = async (playerId: string) => {
    try {
      const { error } = await supabase.from("profiles").update({ status: "approved" }).eq("id", playerId)

      if (error) {
        throw error
      }

      toast({
        title: "Player approved",
        description: "The player has been approved successfully",
      })

      // Update the local state
      setPendingPlayers(pendingPlayers.filter((player) => player.id !== playerId))
    } catch (error: any) {
      toast({
        title: "Error approving player",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const handleRejectPlayer = async (playerId: string) => {
    try {
      const { error } = await supabase.from("profiles").update({ status: "rejected" }).eq("id", playerId)

      if (error) {
        throw error
      }

      toast({
        title: "Player rejected",
        description: "The player has been rejected",
      })

      // Update the local state
      setPendingPlayers(pendingPlayers.filter((player) => player.id !== playerId))
    } catch (error: any) {
      toast({
        title: "Error rejecting player",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Player Approvals</h1>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <UserCheck className="mr-2 h-5 w-5" />
            Pending Player Approvals
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center p-4">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingPlayers.length > 0 ? (
                  pendingPlayers.map((player) => (
                    <TableRow key={player.id}>
                      <TableCell className="font-medium">{player.name}</TableCell>
                      <TableCell>{player.email}</TableCell>
                      <TableCell>{player.phone}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
                          Pending
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          className="mr-2 bg-green-100 text-green-800 hover:bg-green-200"
                          onClick={() => handleApprovePlayer(player.id)}
                        >
                          <UserCheck className="mr-1 h-4 w-4" />
                          Approve
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="bg-red-100 text-red-800 hover:bg-red-200"
                          onClick={() => handleRejectPlayer(player.id)}
                        >
                          <UserX className="mr-1 h-4 w-4" />
                          Reject
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center">
                      No pending player approvals
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}


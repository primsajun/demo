"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useSupabase } from "@/components/providers/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2 } from "lucide-react"

export default function RegisterPage() {
  const [activeTab, setActiveTab] = useState("details")
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [phone, setPhone] = useState("")
  const [aadhar, setAadhar] = useState("")
  const [userType, setUserType] = useState("player") // "admin" or "player"
  const [phoneOtp, setPhoneOtp] = useState("")
  const [aadharOtp, setAadharOtp] = useState("")
  const [loading, setLoading] = useState(false)
  const [sendingOtp, setSendingOtp] = useState(false)
  const [phoneVerified, setPhoneVerified] = useState(false)
  const [aadharVerified, setAadharVerified] = useState(false)
  const [registrationSuccess, setRegistrationSuccess] = useState(false)

  const { supabase } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()

  const sendPhoneOtp = async () => {
    if (!phone || phone.length !== 10) {
      toast({
        title: "Invalid phone number",
        description: "Please enter a valid 10-digit phone number",
        variant: "destructive",
      })
      return
    }

    setSendingOtp(true)
    try {
      // In a real app, you would call your API to send OTP
      // For demo purposes, we'll simulate it
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "OTP Sent",
        description: `A verification code has been sent to ${phone}`,
      })

      // Move to OTP verification tab
      setActiveTab("phone-verification")
    } catch (error: any) {
      toast({
        title: "Failed to send OTP",
        description: error.message || "An error occurred",
        variant: "destructive",
      })
    } finally {
      setSendingOtp(false)
    }
  }

  const verifyPhoneOtp = async () => {
    if (!phoneOtp || phoneOtp.length !== 5) {
      toast({
        title: "Invalid OTP",
        description: "Please enter a valid 5-digit OTP",
        variant: "destructive",
      })
      return
    }

    setSendingOtp(true)
    try {
      // In a real app, you would verify the OTP with your API
      // For demo purposes, we'll simulate it and accept any 5-digit code
      await new Promise((resolve) => setTimeout(resolve, 1500))

      setPhoneVerified(true)
      toast({
        title: "Phone Verified",
        description: "Your phone number has been verified successfully",
      })

      // Move to Aadhar tab
      setActiveTab("aadhar")
    } catch (error: any) {
      toast({
        title: "OTP Verification Failed",
        description: error.message || "An error occurred",
        variant: "destructive",
      })
    } finally {
      setSendingOtp(false)
    }
  }

  const sendAadharOtp = async () => {
    if (!aadhar || aadhar.length !== 12) {
      toast({
        title: "Invalid Aadhar number",
        description: "Please enter a valid 12-digit Aadhar number",
        variant: "destructive",
      })
      return
    }

    setSendingOtp(true)
    try {
      // In a real app, you would call your API to send OTP
      // For demo purposes, we'll simulate it
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "OTP Sent",
        description: `A verification code has been sent to the phone number registered with your Aadhar`,
      })

      // Move to Aadhar OTP verification tab
      setActiveTab("aadhar-verification")
    } catch (error: any) {
      toast({
        title: "Failed to send OTP",
        description: error.message || "An error occurred",
        variant: "destructive",
      })
    } finally {
      setSendingOtp(false)
    }
  }

  const verifyAadharOtp = async () => {
    if (!aadharOtp || aadharOtp.length !== 5) {
      toast({
        title: "Invalid OTP",
        description: "Please enter a valid 5-digit OTP",
        variant: "destructive",
      })
      return
    }

    setSendingOtp(true)
    try {
      // In a real app, you would verify the OTP with your API
      // For demo purposes, we'll simulate it and accept any 5-digit code
      await new Promise((resolve) => setTimeout(resolve, 1500))

      setAadharVerified(true)
      toast({
        title: "Aadhar Verified",
        description: "Your Aadhar number has been verified successfully",
      })

      // Move to final registration tab
      setActiveTab("complete")
    } catch (error: any) {
      toast({
        title: "OTP Verification Failed",
        description: error.message || "An error occurred",
        variant: "destructive",
      })
    } finally {
      setSendingOtp(false)
    }
  }

  const handleRegister = async () => {
    if (password !== confirmPassword) {
      toast({
        title: "Passwords do not match",
        description: "Please make sure your passwords match",
        variant: "destructive",
      })
      return
    }

    if (!phoneVerified || !aadharVerified) {
      toast({
        title: "Verification required",
        description: "Please verify both your phone and Aadhar number",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name: name,
            phone: `+91${phone}`,
            aadhar: aadhar,
            user_type: userType,
            status: "pending", // All new registrations start as pending
          },
        },
      })

      if (error) {
        throw error
      }

      // Create profile in profiles table
      if (data.user) {
        const { error: profileError } = await supabase.from("profiles").insert([
          {
            id: data.user.id,
            name,
            email,
            phone: `+91${phone}`,
            aadhar,
            user_id: data.user.id,
            user_type: userType,
            status: "pending",
          },
        ])

        if (profileError) {
          throw profileError
        }
      }

      toast({
        title: "Registration successful",
        description: "Your account has been created and is pending admin approval",
      })

      setRegistrationSuccess(true)

      // Redirect to login page after 2 seconds
      setTimeout(() => {
        router.push("/login")
      }, 2000)
    } catch (error: any) {
      console.error("Registration Error Details:", {
        message: error.message,
        code: error.code,
        status: error.status,
        details: error.details,
      })
      toast({
        title: "Registration failed",
        description: error.message || "Unknown error occurred",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  if (registrationSuccess) {
    return (
      <div className="min-h-screen flex flex-col">
        <div className="football-bg"></div>
        <main className="flex-1 flex items-center justify-center p-6">
          <Card className="w-full max-w-md bg-white/90 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl text-center">Registration Successful!</CardTitle>
              <CardDescription className="text-center">
                Your account has been created and is pending admin approval.
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="flex justify-center my-4">
                <div className="rounded-full bg-green-100 p-3">
                  <svg
                    className="h-6 w-6 text-green-600"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              </div>
              <p>Redirecting to login page...</p>
              <div className="mt-4 flex justify-center">
                <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <div className="football-bg"></div>
      <main className="flex-1 flex items-center justify-center p-6">
        <Card className="w-full max-w-md bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Register</CardTitle>
            <CardDescription className="text-center">Create an account to get started</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="details" disabled={activeTab !== "details"}>
                  Details
                </TabsTrigger>
                <TabsTrigger value="phone-verification" disabled={activeTab !== "phone-verification" && !phoneVerified}>
                  Phone
                </TabsTrigger>
                <TabsTrigger value="aadhar" disabled={activeTab !== "aadhar" && !phoneVerified}>
                  Aadhar
                </TabsTrigger>
                <TabsTrigger
                  value="complete"
                  disabled={activeTab !== "complete" && (!phoneVerified || !aadharVerified)}
                >
                  Complete
                </TabsTrigger>
              </TabsList>

              <TabsContent value="details" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    placeholder="Enter your full name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    placeholder="Enter your 10-digit phone number"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Account Type</Label>
                  <div className="flex space-x-4">
                    <label className="flex items-center space-x-2">
                      <input
                        type="radio"
                        name="userType"
                        value="player"
                        checked={userType === "player"}
                        onChange={() => setUserType("player")}
                        className="h-4 w-4"
                      />
                      <span>Player</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input
                        type="radio"
                        name="userType"
                        value="admin"
                        checked={userType === "admin"}
                        onChange={() => setUserType("admin")}
                        className="h-4 w-4"
                      />
                      <span>Admin</span>
                    </label>
                  </div>
                </div>
                <Button className="w-full" onClick={sendPhoneOtp} disabled={!name || !email || !phone || sendingOtp}>
                  {sendingOtp ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Sending OTP...
                    </>
                  ) : (
                    "Continue & Verify Phone"
                  )}
                </Button>
              </TabsContent>

              <TabsContent value="phone-verification" className="space-y-4 mt-4">
                <div className="space-y-2 text-center">
                  <h3 className="text-lg font-medium">Verify Your Phone Number</h3>
                  <p className="text-sm text-muted-foreground">We've sent a 5-digit code to {phone}</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phoneOtp">Enter OTP</Label>
                  <div className="flex justify-center py-4">
                    <InputOTP maxLength={5} value={phoneOtp} onChange={setPhoneOtp}>
                      <InputOTPGroup>
                        <InputOTPSlot index={0} />
                        <InputOTPSlot index={1} />
                        <InputOTPSlot index={2} />
                        <InputOTPSlot index={3} />
                        <InputOTPSlot index={4} />
                      </InputOTPGroup>
                    </InputOTP>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    className="w-1/2"
                    onClick={() => setActiveTab("details")}
                    disabled={sendingOtp}
                  >
                    Back
                  </Button>
                  <Button className="w-1/2" onClick={verifyPhoneOtp} disabled={phoneOtp.length !== 5 || sendingOtp}>
                    {sendingOtp ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Verifying...
                      </>
                    ) : (
                      "Verify OTP"
                    )}
                  </Button>
                </div>
                <div className="text-center">
                  <Button variant="link" onClick={sendPhoneOtp} disabled={sendingOtp}>
                    Resend OTP
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="aadhar" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="aadhar">Aadhar Number</Label>
                  <Input
                    id="aadhar"
                    placeholder="Enter your 12-digit Aadhar number"
                    value={aadhar}
                    onChange={(e) => setAadhar(e.target.value.replace(/\D/g, "").slice(0, 12))}
                    required
                  />
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    className="w-1/2"
                    onClick={() => setActiveTab("details")}
                    disabled={sendingOtp}
                  >
                    Back
                  </Button>
                  <Button
                    className="w-1/2"
                    onClick={sendAadharOtp}
                    disabled={!aadhar || aadhar.length !== 12 || sendingOtp}
                  >
                    {sendingOtp ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Sending OTP...
                      </>
                    ) : (
                      "Verify Aadhar"
                    )}
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="aadhar-verification" className="space-y-4 mt-4">
                <div className="space-y-2 text-center">
                  <h3 className="text-lg font-medium">Verify Your Aadhar</h3>
                  <p className="text-sm text-muted-foreground">
                    We've sent a 5-digit code to the phone number registered with your Aadhar
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="aadharOtp">Enter OTP</Label>
                  <div className="flex justify-center py-4">
                    <InputOTP maxLength={5} value={aadharOtp} onChange={setAadharOtp}>
                      <InputOTPGroup>
                        <InputOTPSlot index={0} />
                        <InputOTPSlot index={1} />
                        <InputOTPSlot index={2} />
                        <InputOTPSlot index={3} />
                        <InputOTPSlot index={4} />
                      </InputOTPGroup>
                    </InputOTP>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    className="w-1/2"
                    onClick={() => setActiveTab("aadhar")}
                    disabled={sendingOtp}
                  >
                    Back
                  </Button>
                  <Button className="w-1/2" onClick={verifyAadharOtp} disabled={aadharOtp.length !== 5 || sendingOtp}>
                    {sendingOtp ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Verifying...
                      </>
                    ) : (
                      "Verify OTP"
                    )}
                  </Button>
                </div>
                <div className="text-center">
                  <Button variant="link" onClick={sendAadharOtp} disabled={sendingOtp}>
                    Resend OTP
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="complete" className="space-y-4 mt-4">
                <div className="space-y-2 text-center">
                  <h3 className="text-lg font-medium">Complete Registration</h3>
                  <p className="text-sm text-muted-foreground">
                    Set your password to complete the registration process
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Create a password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="Confirm your password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                  />
                </div>
                <Button
                  className="w-full"
                  onClick={handleRegister}
                  disabled={!password || !confirmPassword || password !== confirmPassword || loading}
                >
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Registering...
                    </>
                  ) : (
                    "Complete Registration"
                  )}
                </Button>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-center text-sm">
              Already have an account?{" "}
              <Link href="/login" className="text-primary hover:underline">
                Login
              </Link>
            </p>
          </CardFooter>
        </Card>
      </main>
    </div>
  )
}


"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "@/components/providers/supabase-provider"
import { PlayerSidebarNav } from "@/components/player/sidebar-nav"
import { SidebarProvider } from "@/components/ui/sidebar"

export default function PlayerDashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { user, loading, supabase } = useSupabase()
  const router = useRouter()
  const [playerAccessLoading, setPlayerAccessLoading] = useState(true)

  useEffect(() => {
    const checkPlayerAccess = async () => {
      setPlayerAccessLoading(true)

      if (!loading) {
        if (!user) {
          console.log("No user found. Redirecting to login from layout 1...")
          router.push("/login")
          setPlayerAccessLoading(false)
          return
        }

        if (user) {
          try {
            const { data: profile, error } = await supabase
              .from("profiles")
              .select("user_type, status")
              .eq("user_id", user.id)
              .single()

            if (error) {
              console.error("Error fetching profile:", error)
              router.push("/login")
              setPlayerAccessLoading(false)
              return
            }

            if (profile?.user_type !== "player" || profile?.status !== "approved") {
              console.log("User is not a player or not approved. Redirecting to login from layout 2...")
              router.push("/login")
              setPlayerAccessLoading(false)
              return
            }

            // Successfully authenticated as player
            setPlayerAccessLoading(false)
          } catch (error) {
            console.error("Error in player access check:", error)
            router.push("/login")
            setPlayerAccessLoading(false)
          }
        }
      }
    }

    if (supabase) {
      checkPlayerAccess()
    }
  }, [user, loading, router, supabase])

  if (loading || playerAccessLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <div className="football-bg"></div>
      <SidebarProvider>
        <div className="flex flex-1">
          <PlayerSidebarNav />
          <div className="flex-1 md:ml-0 pt-14 md:pt-0">{children}</div>
        </div>
      </SidebarProvider>
    </div>
  )
}


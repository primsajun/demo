"use client"

import { useEffect, useRef } from "react"

export function FootballAnimation() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    // Football properties
    const footballs: Football[] = []
    const footballCount = 5

    class Football {
      x: number
      y: number
      radius: number
      speedX: number
      speedY: number
      rotation: number
      rotationSpeed: number
      image: HTMLImageElement
      imageLoaded: boolean

      constructor() {
        this.radius = Math.random() * 20 + 15
        this.x = Math.random() * (canvas.width - this.radius * 2) + this.radius
        this.y = Math.random() * (canvas.height - this.radius * 2) + this.radius
        this.speedX = (Math.random() - 0.5) * 2
        this.speedY = (Math.random() - 0.5) * 2
        this.rotation = 0
        this.rotationSpeed = (Math.random() - 0.5) * 0.1
        this.image = new Image()
        this.imageLoaded = false

        // Set crossOrigin before setting src
        this.image.crossOrigin = "anonymous"
        this.image.onload = () => {
          this.imageLoaded = true
        }
        this.image.onerror = () => {
          console.error("Error loading football image - using fallback")
          // Don't log the error object as it can't be serialized properly
          this.imageLoaded = false
        }

        // Use a try-catch to handle potential errors
        try {
          this.image.src = "/football.png"
        } catch (error) {
          console.error("Error setting image source")
          this.imageLoaded = false
        }
      }

      update() {
        // Update position
        this.x += this.speedX
        this.y += this.speedY

        // Bounce off walls
        if (this.x <= this.radius || this.x >= canvas.width - this.radius) {
          this.speedX = -this.speedX
        }
        if (this.y <= this.radius || this.y >= canvas.height - this.radius) {
          this.speedY = -this.speedY
        }

        // Update rotation
        this.rotation += this.rotationSpeed
      }

      draw() {
        if (!ctx) return

        // Only draw if image is loaded
        if (this.imageLoaded) {
          ctx.save()
          ctx.translate(this.x, this.y)
          ctx.rotate(this.rotation)
          ctx.drawImage(this.image, -this.radius, -this.radius, this.radius * 2, this.radius * 2)
          ctx.restore()
        } else {
          // Fallback to a circle if image isn't loaded
          ctx.beginPath()
          ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2)
          ctx.fillStyle = "#ffffff"
          ctx.fill()
          ctx.closePath()
        }
      }
    }

    // Create footballs
    for (let i = 0; i < footballCount; i++) {
      footballs.push(new Football())
    }

    // Animation loop
    function animate() {
      if (!ctx || !canvas) return

      ctx.clearRect(0, 0, canvas.width, canvas.height)

      footballs.forEach((football) => {
        football.update()
        football.draw()
      })

      requestAnimationFrame(animate)
    }

    animate()

    // Handle window resize
    const handleResize = () => {
      if (!canvas) return
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  return <canvas ref={canvasRef} className="fixed top-0 left-0 w-full h-full pointer-events-none z-0" />
}


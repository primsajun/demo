"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useSupabase } from "@/components/providers/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Database, Settings, Shield, RefreshCw } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function SettingsPage() {
  const { supabase, user } = useSupabase()
  const { toast } = useToast()
  const [isCreatingTables, setIsCreatingTables] = useState(false)
  const [darkMode, setDarkMode] = useState(false)
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [smsNotifications, setSmsNotifications] = useState(false)

  const createRequiredTables = async () => {
    setIsCreatingTables(true)
    try {
      // Create achievements table if it doesn't exist
      const { error: achievementsError } = await supabase.from("achievements").select("id").limit(1)

      if (achievementsError && achievementsError.code === "42P01") {
        // Table doesn't exist
        // Create achievements table
        await supabase.auth.admin.createUser({
          email: "temp@example.com",
          password: "temppassword",
          user_metadata: { temp: true },
        })

        const { error } = await supabase.from("achievements").insert([
          {
            player_id: user?.id,
            title: "Table Created",
            tournament: "System",
            description: "Achievements table created",
          },
        ])

        if (error && error.code !== "42P01") throw error
      }

      // Create match_history table if it doesn't exist
      const { error: matchHistoryError } = await supabase.from("match_history").select("id").limit(1)

      if (matchHistoryError && matchHistoryError.code === "42P01") {
        // Table doesn't exist
        // Create match_history table
        const { error } = await supabase.from("match_history").insert([
          {
            player_id: user?.id,
            tournament: "System",
            opponent: "System",
            result: "Win",
            goals: 0,
          },
        ])

        if (error && error.code !== "42P01") throw error
      }

      // Create match_events table if it doesn't exist
      const { error: matchEventsError } = await supabase.from("match_events").select("id").limit(1)

      if (matchEventsError && matchEventsError.code === "42P01") {
        // Table doesn't exist
        // Create match_events table
        const { error } = await supabase.from("match_events").insert([
          {
            match_id: "00000000-0000-0000-0000-000000000000",
            player_id: user?.id,
            event_type: "system",
            minute: 0,
          },
        ])

        if (error && error.code !== "42P01") throw error
      }

      toast({
        title: "Database check completed",
        description: "All required database tables have been verified.",
      })
    } catch (error: any) {
      console.error("Error checking/creating tables:", error)
      toast({
        title: "Error with database tables",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsCreatingTables(false)
    }
  }

  const handleSaveGeneralSettings = () => {
    toast({
      title: "Settings saved",
      description: "Your general settings have been updated successfully.",
    })
  }

  const handleSaveNotificationSettings = () => {
    toast({
      title: "Notification settings saved",
      description: "Your notification preferences have been updated successfully.",
    })
  }

  const handleSaveSecuritySettings = () => {
    toast({
      title: "Security settings saved",
      description: "Your security settings have been updated successfully.",
    })
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Settings</h1>

      <Tabs defaultValue="general">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">
            <Settings className="mr-2 h-4 w-4" />
            General
          </TabsTrigger>
          <TabsTrigger value="notifications">
            <RefreshCw className="mr-2 h-4 w-4" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="security">
            <Shield className="mr-2 h-4 w-4" />
            Security
          </TabsTrigger>
          <TabsTrigger value="database">
            <Database className="mr-2 h-4 w-4" />
            Database
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>Manage your general application settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="dark-mode">Dark Mode</Label>
                  <Switch id="dark-mode" checked={darkMode} onCheckedChange={setDarkMode} />
                </div>
                <p className="text-sm text-muted-foreground">Enable dark mode for the application interface</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="club-name">Club Name</Label>
                <Input id="club-name" defaultValue="Football Club Management" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="admin-email">Admin Email</Label>
                <Input id="admin-email" type="email" defaultValue="admin@example.com" />
              </div>

              <Button onClick={handleSaveGeneralSettings}>Save Changes</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>Manage how you receive notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="email-notifications">Email Notifications</Label>
                  <Switch
                    id="email-notifications"
                    checked={emailNotifications}
                    onCheckedChange={setEmailNotifications}
                  />
                </div>
                <p className="text-sm text-muted-foreground">Receive notifications via email</p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="sms-notifications">SMS Notifications</Label>
                  <Switch id="sms-notifications" checked={smsNotifications} onCheckedChange={setSmsNotifications} />
                </div>
                <p className="text-sm text-muted-foreground">Receive notifications via SMS</p>
              </div>

              <Button onClick={handleSaveNotificationSettings}>Save Changes</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>Manage your security preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="current-password">Current Password</Label>
                <Input id="current-password" type="password" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="new-password">New Password</Label>
                <Input id="new-password" type="password" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirm-password">Confirm New Password</Label>
                <Input id="confirm-password" type="password" />
              </div>

              <Button onClick={handleSaveSecuritySettings}>Update Password</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="database" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Database Management</CardTitle>
              <CardDescription>Manage database tables and data</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <Database className="h-4 w-4" />
                <AlertTitle>Database Operations</AlertTitle>
                <AlertDescription>These operations affect the database structure. Use with caution.</AlertDescription>
              </Alert>

              <div className="space-y-2">
                <Button onClick={createRequiredTables} disabled={isCreatingTables} className="w-full">
                  {isCreatingTables ? (
                    <>
                      <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
                      Creating Tables...
                    </>
                  ) : (
                    <>
                      <Database className="mr-2 h-4 w-4" />
                      Create Required Tables
                    </>
                  )}
                </Button>
                <p className="text-sm text-muted-foreground">
                  Creates missing tables required by the application if they don't exist
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}


"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useSupabase } from "@/components/providers/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { Award, Calendar, Trophy } from "lucide-react"

interface Achievement {
  id: string
  title: string
  tournament: string
  date: string
  description: string
}

export default function PlayerAchievementsPage() {
  const { supabase, user } = useSupabase()
  const { toast } = useToast()
  const [achievements, setAchievements] = useState<Achievement[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (user) {
      fetchAchievements()
    }
  }, [user])

  const fetchAchievements = async () => {
    setLoading(true)
    try {
      // Check if achievements table exists
      try {
        const { error: achievementsError } = await supabase.from("achievements").select("id").limit(1)

        if (achievementsError) {
          console.log("Achievements table may not exist yet. Please use the Settings page to create required tables.")
        }
      } catch (error) {
        console.error("Error checking achievements table:", error)
      }

      // Fetch player achievements
      const { data, error } = await supabase
        .from("achievements")
        .select("*")
        .eq("player_id", user?.id)
        .order("date", { ascending: false })

      if (error) {
        throw error
      }

      setAchievements(data || [])
    } catch (error: any) {
      console.error("Error fetching achievements:", error)
      toast({
        title: "Error fetching achievements",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">My Achievements</h1>

      {achievements.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6">
            <Award className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-center text-muted-foreground">You haven't earned any achievements yet.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {achievements.map((achievement) => (
            <Card key={achievement.id} className="overflow-hidden">
              <div className="bg-primary/10 p-2 flex justify-center">
                <Award className="h-8 w-8 text-primary" />
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-xl">{achievement.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center text-sm">
                  <Trophy className="h-4 w-4 mr-2 text-muted-foreground" />
                  <span>{achievement.tournament || "General Achievement"}</span>
                </div>
                <div className="flex items-center text-sm">
                  <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                  <span>{new Date(achievement.date).toLocaleDateString()}</span>
                </div>
                {achievement.description && (
                  <p className="text-sm text-muted-foreground mt-2">{achievement.description}</p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}


"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { useSupabase } from "@/components/providers/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ArrowLeft, Calendar, Clock, MapPin, Trophy, Users } from "lucide-react"

interface Match {
  id: string
  team_a: string
  team_b: string
  date: string
  time: string
  venue: string
  tournament_id: string
  tournament_name?: string
  score_team_a: number | null
  score_team_b: number | null
  status: string
}

interface MatchEvent {
  id: string
  match_id: string
  player_id: string
  player_name?: string
  team?: string
  event_type: string
  minute: number
  timestamp: string
}

interface PlayerStat {
  player_id: string
  player_name: string
  team: string
  goals: number
  assists: number
  yellow_cards: number
  red_cards: number
}

export default function MatchSummaryDetailPage() {
  const params = useParams()
  const matchId = params.id as string
  const router = useRouter()
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [match, setMatch] = useState<Match | null>(null)
  const [matchEvents, setMatchEvents] = useState<MatchEvent[]>([])
  const [playerStats, setPlayerStats] = useState<PlayerStat[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (matchId) {
      fetchMatchDetails()
    }
  }, [matchId])

  const fetchMatchDetails = async () => {
    setLoading(true)
    try {
      // Fetch match details
      const { data: matchData, error: matchError } = await supabase
        .from("matches")
        .select(`
          *,
          tournaments:tournament_id (name)
        `)
        .eq("id", matchId)
        .single()

      if (matchError) throw matchError

      // Format match data
      const formattedMatch = {
        ...matchData,
        tournament_name: matchData.tournaments?.name || "Unknown Tournament",
      }

      setMatch(formattedMatch)

      // Fetch match events
      const { data: eventsData, error: eventsError } = await supabase
        .from("match_events")
        .select(`
          id,
          match_id,
          player_id,
          event_type,
          minute,
          timestamp
        `)
        .eq("match_id", matchId)
        .order("minute", { ascending: true })

      if (eventsError) throw eventsError

      // Fetch player names and teams for each event
      const eventsWithPlayerInfo = await Promise.all(
        (eventsData || []).map(async (event) => {
          try {
            const { data: playerData } = await supabase
              .from("profiles")
              .select("name, team")
              .eq("id", event.player_id)
              .single()

            return {
              ...event,
              player_name: playerData?.name || "Unknown Player",
              team: playerData?.team || "Unknown Team",
            }
          } catch (error) {
            return {
              ...event,
              player_name: "Unknown Player",
              team: "Unknown Team",
            }
          }
        }),
      )

      setMatchEvents(eventsWithPlayerInfo)

      // Calculate player statistics
      calculatePlayerStats(eventsWithPlayerInfo)
    } catch (error: any) {
      console.error("Error fetching match details:", error)
      toast({
        title: "Error fetching match details",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const calculatePlayerStats = (events: MatchEvent[]) => {
    const stats: Record<string, PlayerStat> = {}

    // Initialize stats for each player
    events.forEach((event) => {
      if (!stats[event.player_id]) {
        stats[event.player_id] = {
          player_id: event.player_id,
          player_name: event.player_name || "Unknown Player",
          team: event.team || "Unknown Team",
          goals: 0,
          assists: 0,
          yellow_cards: 0,
          red_cards: 0,
        }
      }
    })

    // Count events for each player
    events.forEach((event) => {
      const playerStat = stats[event.player_id]
      if (playerStat) {
        switch (event.event_type) {
          case "goal":
            playerStat.goals += 1
            break
          case "assist":
            playerStat.assists += 1
            break
          case "yellow-card":
            playerStat.yellow_cards += 1
            break
          case "red-card":
            playerStat.red_cards += 1
            break
        }
      }
    })

    // Convert to array and sort by goals
    const statsArray = Object.values(stats).sort((a, b) => b.goals - a.goals)
    setPlayerStats(statsArray)
  }

  const getEventIcon = (eventType: string) => {
    switch (eventType) {
      case "goal":
        return "⚽"
      case "yellow-card":
        return "🟨"
      case "red-card":
        return "🟥"
      case "assist":
        return "👟"
      case "substitution":
        return "🔄"
      default:
        return "📝"
    }
  }

  const getEventLabel = (eventType: string) => {
    switch (eventType) {
      case "goal":
        return "Goal"
      case "yellow-card":
        return "Yellow Card"
      case "red-card":
        return "Red Card"
      case "assist":
        return "Assist"
      case "substitution":
        return "Substitution"
      default:
        return eventType.charAt(0).toUpperCase() + eventType.slice(1)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "live":
        return <Badge className="bg-green-100 text-green-800">Live</Badge>
      case "scheduled":
        return <Badge className="bg-blue-100 text-blue-800">Scheduled</Badge>
      case "completed":
        return <Badge className="bg-gray-100 text-gray-800">Completed</Badge>
      case "postponed":
        return <Badge className="bg-yellow-100 text-yellow-800">Postponed</Badge>
      case "cancelled":
        return <Badge className="bg-red-100 text-red-800">Cancelled</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
      </div>
    )
  }

  if (!match) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => router.back()}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
        </div>
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-8">
            <p className="text-center text-muted-foreground mb-4">Match not found</p>
            <Button onClick={() => router.push("/admin/dashboard/match-summary")}>View All Matches</Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="outline" size="sm" onClick={() => router.back()}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <CardTitle className="text-2xl md:text-3xl">
                {match.team_a} vs {match.team_b}
              </CardTitle>
              <CardDescription className="flex flex-wrap items-center gap-2 mt-2">
                <span className="flex items-center">
                  <Trophy className="mr-1 h-4 w-4" />
                  {match.tournament_name}
                </span>
                <span className="flex items-center">
                  <Calendar className="mr-1 h-4 w-4" />
                  {new Date(match.date).toLocaleDateString()}
                </span>
                <span className="flex items-center">
                  <Clock className="mr-1 h-4 w-4" />
                  {match.time}
                </span>
                <span className="flex items-center">
                  <MapPin className="mr-1 h-4 w-4" />
                  {match.venue}
                </span>
              </CardDescription>
            </div>
            <div>{getStatusBadge(match.status)}</div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex justify-center items-center py-6 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <div className="text-center px-8">
              <div className="text-xl font-bold">{match.team_a}</div>
              <div className="text-6xl font-bold mt-2">{match.score_team_a || 0}</div>
            </div>
            <div className="text-2xl font-bold px-4">-</div>
            <div className="text-center px-8">
              <div className="text-xl font-bold">{match.team_b}</div>
              <div className="text-6xl font-bold mt-2">{match.score_team_b || 0}</div>
            </div>
          </div>

          <Tabs defaultValue="timeline">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="timeline">Timeline</TabsTrigger>
              <TabsTrigger value="stats">Player Stats</TabsTrigger>
              <TabsTrigger value="lineups">Lineups</TabsTrigger>
            </TabsList>

            <TabsContent value="timeline" className="space-y-4 mt-4">
              <div className="space-y-2">
                <h3 className="font-medium flex items-center">
                  <Clock className="mr-2 h-4 w-4" />
                  Match Timeline
                </h3>
                {matchEvents.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Time</TableHead>
                        <TableHead>Event</TableHead>
                        <TableHead>Player</TableHead>
                        <TableHead>Team</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {matchEvents.map((event) => (
                        <TableRow key={event.id}>
                          <TableCell className="font-medium">{event.minute}'</TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <span className="mr-2 text-xl">{getEventIcon(event.event_type)}</span>
                              <span>{getEventLabel(event.event_type)}</span>
                            </div>
                          </TableCell>
                          <TableCell>{event.player_name}</TableCell>
                          <TableCell>{event.team}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">No events recorded for this match</div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="stats" className="space-y-4 mt-4">
              <div className="space-y-2">
                <h3 className="font-medium flex items-center">
                  <Users className="mr-2 h-4 w-4" />
                  Player Statistics
                </h3>
                {playerStats.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Player</TableHead>
                        <TableHead>Team</TableHead>
                        <TableHead>Goals</TableHead>
                        <TableHead>Assists</TableHead>
                        <TableHead>Yellow Cards</TableHead>
                        <TableHead>Red Cards</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {playerStats.map((stat) => (
                        <TableRow key={stat.player_id}>
                          <TableCell className="font-medium">{stat.player_name}</TableCell>
                          <TableCell>{stat.team}</TableCell>
                          <TableCell>{stat.goals}</TableCell>
                          <TableCell>{stat.assists}</TableCell>
                          <TableCell>{stat.yellow_cards}</TableCell>
                          <TableCell>{stat.red_cards}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">No player statistics available</div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="lineups" className="space-y-4 mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>{match.team_a}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8 text-muted-foreground">Lineup information not available</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{match.team_b}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8 text-muted-foreground">Lineup information not available</div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => router.push("/admin/dashboard/match-summary")}>
            All Matches
          </Button>
          {match.status === "scheduled" && (
            <Button onClick={() => router.push(`/admin/dashboard/matches`)}>Edit Match</Button>
          )}
          {match.status === "live" && (
            <Button onClick={() => router.push(`/admin/dashboard/live`)}>Live Updates</Button>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}


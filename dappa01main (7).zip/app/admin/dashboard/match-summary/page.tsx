"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "@/components/providers/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, ChevronRight, Search } from "lucide-react"
import { Input } from "@/components/ui/input"

interface Match {
  id: string
  team_a: string
  team_b: string
  date: string
  time: string
  venue: string
  tournament_id: string
  tournament_name?: string
  score_team_a: number | null
  score_team_b: number | null
  status: string
}

export default function MatchSummaryPage() {
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const router = useRouter()
  const [matches, setMatches] = useState<Match[]>([])
  const [filteredMatches, setFilteredMatches] = useState<Match[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    fetchMatches()
  }, [])

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredMatches(matches)
    } else {
      const query = searchQuery.toLowerCase()
      const filtered = matches.filter(
        (match) =>
          match.team_a.toLowerCase().includes(query) ||
          match.team_b.toLowerCase().includes(query) ||
          match.venue.toLowerCase().includes(query) ||
          match.tournament_name?.toLowerCase().includes(query) ||
          match.status.toLowerCase().includes(query),
      )
      setFilteredMatches(filtered)
    }
  }, [searchQuery, matches])

  const fetchMatches = async () => {
    setLoading(true)
    try {
      // Fetch matches with tournament names
      const { data, error } = await supabase
        .from("matches")
        .select(`
          *,
          tournaments:tournament_id (name)
        `)
        .order("date", { ascending: false })

      if (error) throw error

      // Format the data to include tournament name
      const formattedData = data.map((match) => ({
        ...match,
        tournament_name: match.tournaments?.name || "Unknown Tournament",
      }))

      setMatches(formattedData)
      setFilteredMatches(formattedData)
    } catch (error: any) {
      console.error("Error fetching matches:", error)
      toast({
        title: "Error fetching matches",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleViewSummary = (matchId: string) => {
    router.push(`/admin/dashboard/match-summary/${matchId}`)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "live":
        return <Badge className="bg-green-500/20 text-green-400 hover:bg-green-500/30">Live</Badge>
      case "scheduled":
        return <Badge className="bg-blue-500/20 text-blue-400 hover:bg-blue-500/30">Scheduled</Badge>
      case "completed":
        return <Badge className="bg-gray-500/20 text-gray-400 hover:bg-gray-500/30">Completed</Badge>
      case "postponed":
        return <Badge className="bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30">Postponed</Badge>
      case "cancelled":
        return <Badge className="bg-red-500/20 text-red-400 hover:bg-red-500/30">Cancelled</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Match Summaries</h1>

      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search matches..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <Card className="bg-gradient-to-b from-card to-card/90 border-accent/20">
        <CardHeader>
          <CardTitle className="flex items-center text-primary">
            <Calendar className="mr-2 h-5 w-5" />
            All Matches
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center p-4">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-accent/20">
                  <TableHead>Teams</TableHead>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>Tournament</TableHead>
                  <TableHead>Score</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMatches.length > 0 ? (
                  filteredMatches.map((match) => (
                    <TableRow key={match.id} className="border-accent/10 hover:bg-accent/5">
                      <TableCell className="font-medium">
                        {match.team_a} vs {match.team_b}
                      </TableCell>
                      <TableCell>
                        {new Date(match.date).toLocaleDateString()} {match.time}
                      </TableCell>
                      <TableCell>{match.tournament_name}</TableCell>
                      <TableCell>
                        {match.score_team_a !== null && match.score_team_b !== null
                          ? `${match.score_team_a} - ${match.score_team_b}`
                          : "Not played"}
                      </TableCell>
                      <TableCell>{getStatusBadge(match.status)}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="flex items-center gap-1 hover:text-primary hover:bg-primary/10"
                          onClick={() => handleViewSummary(match.id)}
                        >
                          View Summary
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center">
                      No matches found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}


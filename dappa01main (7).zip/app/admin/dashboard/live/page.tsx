"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { useSupabase } from "@/components/providers/supabase-provider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Activity, Plus, Trophy, Clock, AlertCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface Match {
  id: string
  team_a: string
  team_b: string
  date: string
  time: string
  venue: string
  tournament_id: string
  score_team_a: number | null
  score_team_b: number | null
  status: string
}

interface Player {
  id: string
  name: string
  team: string
}

interface MatchEvent {
  id: string
  match_id: string
  player_id: string
  player_name?: string
  team?: string
  event_type: string
  minute: number
  timestamp: string
}

export default function LiveUpdatesPage() {
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [liveMatches, setLiveMatches] = useState<Match[]>([])
  const [players, setPlayers] = useState<Player[]>([])
  const [selectedMatch, setSelectedMatch] = useState("")
  const [selectedPlayer, setSelectedPlayer] = useState("")
  const [eventType, setEventType] = useState("goal")
  const [minute, setMinute] = useState("")
  const [matchEvents, setMatchEvents] = useState<MatchEvent[]>([])
  const [loading, setLoading] = useState(true)
  const [eventsLoading, setEventsLoading] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    fetchLiveMatches()

    // Set up real-time subscription for match events
    const eventsSubscription = supabase
      .channel("public:match_events")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "match_events",
        },
        (payload) => {
          if (selectedMatch && payload.new.match_id === selectedMatch) {
            fetchMatchEvents(selectedMatch)
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(eventsSubscription)
    }
  }, [])

  useEffect(() => {
    if (selectedMatch) {
      fetchMatchEvents(selectedMatch)
      fetchPlayersForMatch(selectedMatch)
    }
  }, [selectedMatch])

  const fetchLiveMatches = async () => {
    setLoading(true)
    try {
      // First try to get matches with status "live"
      const { data: liveData, error: liveError } = await supabase
        .from("matches")
        .select("*")
        .eq("status", "live")
        .order("date", { ascending: false })

      if (liveError) throw liveError

      // If no live matches, get scheduled matches that could be set to live
      let matchesData = liveData || []
      if (matchesData.length === 0) {
        const { data: scheduledData, error: scheduledError } = await supabase
          .from("matches")
          .select("*")
          .eq("status", "scheduled")
          .gte("date", new Date().toISOString().split("T")[0])
          .order("date", { ascending: true })
          .limit(5)

        if (scheduledError) throw scheduledError
        matchesData = scheduledData || []
      }

      setLiveMatches(matchesData)

      // Auto-select the first match if available
      if (matchesData.length > 0 && !selectedMatch) {
        setSelectedMatch(matchesData[0].id)
      }
    } catch (error: any) {
      console.error("Error fetching matches:", error)
      toast({
        title: "Error fetching matches",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const fetchPlayersForMatch = async (matchId: string) => {
    try {
      // Find the selected match
      const match = liveMatches.find((m) => m.id === matchId)
      if (!match) return

      // Get players from both teams
      const { data, error } = await supabase
        .from("profiles")
        .select("id, name, team")
        .in("team", [match.team_a, match.team_b])
        .eq("status", "approved")
        .eq("user_type", "player")
        .order("name")

      if (error) throw error
      setPlayers(data || [])
    } catch (error: any) {
      console.error("Error fetching players:", error)
      toast({
        title: "Error fetching players",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const fetchMatchEvents = async (matchId: string) => {
    setEventsLoading(true)
    try {
      // Get events for this match
      const { data: eventsData, error: eventsError } = await supabase
        .from("match_events")
        .select(`
        id,
        match_id,
        player_id,
        event_type,
        minute,
        timestamp
      `)
        .eq("match_id", matchId)
        .order("minute", { ascending: true })

      if (eventsError) throw eventsError

      // Fetch player names and teams for each event
      const eventsWithPlayerNames = await Promise.all(
        (eventsData || []).map(async (event) => {
          try {
            const { data: playerData } = await supabase
              .from("profiles")
              .select("name, team")
              .eq("id", event.player_id)
              .single()

            return {
              ...event,
              player_name: playerData?.name || "Unknown Player",
              team: playerData?.team || "Unknown Team",
            }
          } catch (error) {
            return {
              ...event,
              player_name: "Unknown Player",
              team: "Unknown Team",
            }
          }
        }),
      )

      setMatchEvents(eventsWithPlayerNames)
    } catch (error: any) {
      console.error("Error fetching match events:", error)
      toast({
        title: "Error fetching match events",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setEventsLoading(false)
    }
  }

  const handleAddEvent = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedMatch || !selectedPlayer || !eventType || !minute) {
      toast({
        title: "Missing information",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      return
    }

    setSubmitting(true)

    try {
      // Add the event to the database
      const { error } = await supabase.from("match_events").insert({
        match_id: selectedMatch,
        player_id: selectedPlayer,
        event_type: eventType,
        minute: Number.parseInt(minute),
        timestamp: new Date().toISOString(),
      })

      if (error) throw error

      // If it's a goal, update the match score
      if (eventType === "goal") {
        // Get the player's team
        const { data: playerData, error: playerError } = await supabase
          .from("profiles")
          .select("team")
          .eq("id", selectedPlayer)
          .single()

        if (playerError) throw playerError

        // Get the match details
        const { data: matchData, error: matchError } = await supabase
          .from("matches")
          .select("*")
          .eq("id", selectedMatch)
          .single()

        if (matchError) throw matchError

        // Update the score based on which team scored
        const isTeamA = playerData.team === matchData.team_a
        const scoreTeamA = isTeamA ? (matchData.score_team_a || 0) + 1 : matchData.score_team_a || 0
        const scoreTeamB = !isTeamA ? (matchData.score_team_b || 0) + 1 : matchData.score_team_b || 0

        const { error: updateError } = await supabase
          .from("matches")
          .update({
            score_team_a: scoreTeamA,
            score_team_b: scoreTeamB,
            status: "live", // Ensure the match is marked as live
          })
          .eq("id", selectedMatch)

        if (updateError) throw updateError
      }

      toast({
        title: "Event added",
        description: `${eventType.charAt(0).toUpperCase() + eventType.slice(1)} at minute ${minute} has been recorded`,
      })

      // Reset form
      setMinute("")

      // Refresh events
      fetchMatchEvents(selectedMatch)
    } catch (error: any) {
      toast({
        title: "Error adding event",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const handleStartMatch = async (matchId: string) => {
    try {
      const { error } = await supabase
        .from("matches")
        .update({
          status: "live",
          score_team_a: 0,
          score_team_b: 0,
        })
        .eq("id", matchId)

      if (error) throw error

      toast({
        title: "Match started",
        description: "The match is now live",
      })

      // Refresh matches
      fetchLiveMatches()
    } catch (error: any) {
      toast({
        title: "Error starting match",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const handleEndMatch = async (matchId: string) => {
    try {
      const { error } = await supabase
        .from("matches")
        .update({
          status: "completed",
        })
        .eq("id", matchId)

      if (error) throw error

      toast({
        title: "Match ended",
        description: "The match has been marked as completed",
      })

      // Refresh matches
      fetchLiveMatches()
    } catch (error: any) {
      toast({
        title: "Error ending match",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const getEventIcon = (eventType: string) => {
    switch (eventType) {
      case "goal":
        return "⚽"
      case "yellow-card":
        return "🟨"
      case "red-card":
        return "🟥"
      case "assist":
        return "👟"
      case "substitution":
        return "🔄"
      default:
        return "📝"
    }
  }

  const getEventLabel = (eventType: string) => {
    switch (eventType) {
      case "goal":
        return "Goal"
      case "yellow-card":
        return "Yellow Card"
      case "red-card":
        return "Red Card"
      case "assist":
        return "Assist"
      case "substitution":
        return "Substitution"
      default:
        return eventType.charAt(0).toUpperCase() + eventType.slice(1)
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Live Match Updates</h1>

      {liveMatches.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-8">
            <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-center text-muted-foreground mb-4">No live or upcoming matches found.</p>
            <Button onClick={() => (window.location.href = "/admin/dashboard/matches")}>Manage Matches</Button>
          </CardContent>
        </Card>
      ) : (
        <Tabs defaultValue="add-event">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="add-event">Add Event</TabsTrigger>
            <TabsTrigger value="match-summary">Match Summary</TabsTrigger>
          </TabsList>

          <TabsContent value="add-event" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="mr-2 h-5 w-5" />
                  Add Live Match Event
                </CardTitle>
                <CardDescription>Record goals, cards, and other events during a live match</CardDescription>
              </CardHeader>
              <form onSubmit={handleAddEvent}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="match">Select Match</Label>
                    <Select value={selectedMatch} onValueChange={setSelectedMatch}>
                      <SelectTrigger id="match">
                        <SelectValue placeholder="Select a match" />
                      </SelectTrigger>
                      <SelectContent>
                        {liveMatches.map((match) => (
                          <SelectItem key={match.id} value={match.id}>
                            {match.team_a} vs {match.team_b}
                            {match.status === "live" ? " (LIVE)" : " (Scheduled)"}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedMatch && liveMatches.find((m) => m.id === selectedMatch)?.status !== "live" && (
                    <div className="bg-yellow-50 p-4 rounded-md flex items-start space-x-3">
                      <AlertCircle className="h-5 w-5 text-yellow-500 mt-0.5" />
                      <div>
                        <h3 className="font-medium text-yellow-800">Match not started</h3>
                        <p className="text-yellow-700 text-sm mt-1">
                          This match is scheduled but not live yet. Start the match to record events.
                        </p>
                        <Button
                          className="mt-2 bg-yellow-500 hover:bg-yellow-600 text-white"
                          onClick={() => handleStartMatch(selectedMatch)}
                        >
                          Start Match
                        </Button>
                      </div>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="player">Select Player</Label>
                    <Select
                      value={selectedPlayer}
                      onValueChange={setSelectedPlayer}
                      disabled={!selectedMatch || liveMatches.find((m) => m.id === selectedMatch)?.status !== "live"}
                    >
                      <SelectTrigger id="player">
                        <SelectValue placeholder="Select a player" />
                      </SelectTrigger>
                      <SelectContent>
                        {players.length > 0 ? (
                          players.map((player) => (
                            <SelectItem key={player.id} value={player.id}>
                              {player.name} ({player.team})
                            </SelectItem>
                          ))
                        ) : (
                          <SelectItem value="no-players" disabled>
                            No players found
                          </SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="event-type">Event Type</Label>
                    <Select
                      value={eventType}
                      onValueChange={setEventType}
                      disabled={!selectedMatch || liveMatches.find((m) => m.id === selectedMatch)?.status !== "live"}
                    >
                      <SelectTrigger id="event-type">
                        <SelectValue placeholder="Select event type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="goal">Goal</SelectItem>
                        <SelectItem value="yellow-card">Yellow Card</SelectItem>
                        <SelectItem value="red-card">Red Card</SelectItem>
                        <SelectItem value="assist">Assist</SelectItem>
                        <SelectItem value="substitution">Substitution</SelectItem>
                        <SelectItem value="foul">Foul</SelectItem>
                        <SelectItem value="penalty">Penalty</SelectItem>
                        <SelectItem value="corner">Corner</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="minute">Minute</Label>
                    <Input
                      id="minute"
                      type="number"
                      placeholder="Enter minute"
                      min="1"
                      max="120"
                      value={minute}
                      onChange={(e) => setMinute(e.target.value)}
                      disabled={!selectedMatch || liveMatches.find((m) => m.id === selectedMatch)?.status !== "live"}
                    />
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => handleEndMatch(selectedMatch)}
                    disabled={!selectedMatch || liveMatches.find((m) => m.id === selectedMatch)?.status !== "live"}
                  >
                    End Match
                  </Button>
                  <Button
                    type="submit"
                    disabled={
                      submitting ||
                      !selectedMatch ||
                      !selectedPlayer ||
                      !minute ||
                      liveMatches.find((m) => m.id === selectedMatch)?.status !== "live"
                    }
                  >
                    {submitting ? "Adding Event..." : "Add Event"}
                  </Button>
                </CardFooter>
              </form>
            </Card>
          </TabsContent>

          <TabsContent value="match-summary" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center">
                      <Trophy className="mr-2 h-5 w-5" />
                      {selectedMatch && liveMatches.find((m) => m.id === selectedMatch) ? (
                        <>
                          {liveMatches.find((m) => m.id === selectedMatch)?.team_a} vs{" "}
                          {liveMatches.find((m) => m.id === selectedMatch)?.team_b}
                        </>
                      ) : (
                        "Select a match"
                      )}
                    </CardTitle>
                    {selectedMatch && liveMatches.find((m) => m.id === selectedMatch) && (
                      <CardDescription>
                        {liveMatches.find((m) => m.id === selectedMatch)?.venue} •{" "}
                        {new Date(liveMatches.find((m) => m.id === selectedMatch)?.date || "").toLocaleDateString()}
                      </CardDescription>
                    )}
                  </div>
                  {selectedMatch && liveMatches.find((m) => m.id === selectedMatch)?.status === "live" && (
                    <Badge className="bg-red-100 text-red-800">LIVE</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {selectedMatch ? (
                  <>
                    <div className="flex justify-center items-center py-4">
                      <div className="text-center px-8">
                        <div className="text-xl font-bold">
                          {liveMatches.find((m) => m.id === selectedMatch)?.team_a}
                        </div>
                        <div className="text-5xl font-bold mt-2">
                          {liveMatches.find((m) => m.id === selectedMatch)?.score_team_a || 0}
                        </div>
                      </div>
                      <div className="text-2xl font-bold px-4">-</div>
                      <div className="text-center px-8">
                        <div className="text-xl font-bold">
                          {liveMatches.find((m) => m.id === selectedMatch)?.team_b}
                        </div>
                        <div className="text-5xl font-bold mt-2">
                          {liveMatches.find((m) => m.id === selectedMatch)?.score_team_b || 0}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h3 className="font-medium flex items-center">
                        <Clock className="mr-2 h-4 w-4" />
                        Match Timeline
                      </h3>
                      {eventsLoading ? (
                        <div className="flex justify-center p-4">
                          <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                        </div>
                      ) : matchEvents.length > 0 ? (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Time</TableHead>
                              <TableHead>Event</TableHead>
                              <TableHead>Player</TableHead>
                              <TableHead>Team</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {matchEvents.map((event) => (
                              <TableRow key={event.id}>
                                <TableCell className="font-medium">{event.minute}'</TableCell>
                                <TableCell>
                                  <div className="flex items-center">
                                    <span className="mr-2 text-xl">{getEventIcon(event.event_type)}</span>
                                    <span>{getEventLabel(event.event_type)}</span>
                                  </div>
                                </TableCell>
                                <TableCell>{event.player_name}</TableCell>
                                <TableCell>{event.team}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      ) : (
                        <div className="text-center py-8 text-muted-foreground">No events recorded yet</div>
                      )}
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">Please select a match to view details</div>
                )}
              </CardContent>
              {selectedMatch && (
                <CardFooter>
                  <Button variant="outline" className="w-full" onClick={() => setSelectedMatch("")}>
                    <Plus className="mr-2 h-4 w-4" />
                    Select Different Match
                  </Button>
                </CardFooter>
              )}
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}


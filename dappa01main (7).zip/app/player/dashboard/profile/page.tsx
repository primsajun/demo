"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useSupabase } from "@/components/providers/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Award, User, Calendar, Mail, Phone, Shield, Edit } from "lucide-react"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

interface PlayerProfile {
  id: string
  name: string
  email: string
  phone: string
  position: string
  team: string
  jersey_number: number
  age: number
  nationality: string
  rating: number
  status: string
  joined_date: Date
}

interface Achievement {
  id: string
  title: string
  tournament: string
  date: string
  description: string
}

interface MatchHistory {
  id: string
  tournament: string
  opponent: string
  result: string
  date: string
  goals: number
}

export default function PlayerProfilePage() {
  const { supabase, user } = useSupabase()
  const { toast } = useToast()
  const [profile, setProfile] = useState<PlayerProfile | null>(null)
  const [achievements, setAchievements] = useState<Achievement[]>([])
  const [matchHistory, setMatchHistory] = useState<MatchHistory[]>([])
  const [loading, setLoading] = useState(true)

  const [editModalOpen, setEditModalOpen] = useState(false)
  const [updatedProfile, setUpdatedProfile] = useState<Partial<PlayerProfile>>({})
  useEffect(() => {
    if (user) {
      fetchPlayerProfile()
    }
  }, [user])

  const fetchPlayerProfile = async () => {
    setLoading(true)
    try {
      // Fetch player profile
      const { data: profileData, error: profileError } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user?.id)
        .single()

      if (profileError) throw profileError
      setProfile(profileData)

      // Check if achievements table exists
      try {
        const { error: achievementsError } = await supabase.from("achievements").select("id").limit(1)

        if (achievementsError) {
          console.log("Achievements table may not exist yet. This is normal if it's your first time.")
        }
      } catch (error) {
        console.error("Error checking achievements table:", error)
      }

      // Check if match_history table exists
      try {
        const { error: matchHistoryError } = await supabase.from("match_history").select("id").limit(1)

        if (matchHistoryError) {
          console.log("Match history table may not exist yet. This is normal if it's your first time.")
        }
      } catch (error) {
        console.error("Error checking match_history table:", error)
      }

      // Fetch player achievements
      try {
        const { data: achievementsData } = await supabase
          .from("achievements")
          .select("*")
          .eq("player_id", user?.id)
          .order("date", { ascending: false })

        setAchievements(achievementsData || [])
      } catch (error) {
        console.error("Error fetching achievements:", error)
        setAchievements([])
      }

      // Fetch match history
      try {
        const { data: matchHistoryData } = await supabase
          .from("match_history")
          .select("*")
          .eq("player_id", user?.id)
          .order("date", { ascending: false })

        setMatchHistory(matchHistoryData || [])
      } catch (error) {
        console.error("Error fetching match history:", error)
        setMatchHistory([])
      }
    } catch (error) {
      console.error("Error fetching player profile:", error)
      toast({
        title: "Error",
        description: "Failed to load profile data",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }
  //update profile

  const handleUpdateProfile = async () => {
    try {
      const { error } = await supabase.from("profiles").update(updatedProfile).eq("id", user?.id)

      if (error) throw error

      toast({ title: "Success", description: "Profile updated successfully", variant: "success" })
      setEditModalOpen(false)
      fetchPlayerProfile()
    } catch (error) {
      console.error("Error updating profile:", error)
      toast({ title: "Error", description: "Failed to update profile", variant: "destructive" })
    }
  }
  if (loading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
      </div>
    )
  }

  // If profile is null, show a message instead of trying to render the profile
  if (!profile) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center">Profile Not Found</CardTitle>
            <CardDescription className="text-center">
              Your profile information could not be loaded. Please try again later.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    )
  }

  // Default values for missing profile data
  const displayName = profile.name || "Player"
  const displayPosition = profile.position || "Position not set"
  const displayTeam = profile.team || "Team not assigned"
  const displayRating = profile.rating || 0
  const displayJerseyNumber = profile.jersey_number || 0
  const displayAge = profile.age || 0
  const displayNationality = profile.nationality || "Not specified"

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">My Profile</h1>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-1">
          <CardHeader className="text-center">
            <Avatar className="mx-auto h-24 w-24">
              <AvatarImage src="/placeholder-user.jpg" alt={displayName} />
              <AvatarFallback>{displayName.charAt(0)}</AvatarFallback>
            </Avatar>
            <CardTitle className="mt-4">{displayName}</CardTitle>
            <Button
              variant="outline"
              onClick={() => {
                setEditModalOpen(true)
                setUpdatedProfile(profile || {})
              }}
            >
              <Edit className="h-4 w-4 mr-2" /> Edit Profile
            </Button>
            <CardDescription>
              {displayPosition} • {displayTeam}
            </CardDescription>
            <div className="mt-2 flex justify-center">
              <Badge className="bg-green-100 text-green-800 hover:bg-green-100">{profile.status}</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-2">
              <Mail className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">{profile.email}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Phone className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">{profile.phone}</span>
            </div>
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">
                {displayNationality}, {displayAge} years
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Shield className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">Jersey #{displayJerseyNumber}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">
                Joined {profile.joined_date ? new Date(profile.joined_date).toLocaleDateString() : "N/A"}
              </span>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Player Rating</span>
                <span className="text-sm font-medium">{displayRating}/10</span>
              </div>
              <Progress value={displayRating * 10} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Player Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="achievements">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="achievements">Achievements</TabsTrigger>
                <TabsTrigger value="matches">Match History</TabsTrigger>
              </TabsList>
              <TabsContent value="achievements" className="mt-4">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Achievement</TableHead>
                      <TableHead>Tournament</TableHead>
                      <TableHead>Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {achievements.length > 0 ? (
                      achievements.map((achievement) => (
                        <TableRow key={achievement.id}>
                          <TableCell className="flex items-center">
                            <Award className="mr-2 h-4 w-4 text-yellow-500" />
                            <span className="font-medium">{achievement.title}</span>
                          </TableCell>
                          <TableCell>{achievement.tournament}</TableCell>
                          <TableCell>{new Date(achievement.date).toLocaleDateString()}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={3} className="text-center">
                          No achievements yet
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </TabsContent>
              <TabsContent value="matches" className="mt-4">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Tournament</TableHead>
                      <TableHead>Opponent</TableHead>
                      <TableHead>Result</TableHead>
                      <TableHead>Goals</TableHead>
                      <TableHead>Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {matchHistory.length > 0 ? (
                      matchHistory.map((match) => (
                        <TableRow key={match.id}>
                          <TableCell className="font-medium">{match.tournament}</TableCell>
                          <TableCell>{match.opponent}</TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={
                                match.result === "Win"
                                  ? "bg-green-100 text-green-800"
                                  : match.result === "Loss"
                                    ? "bg-red-100 text-red-800"
                                    : "bg-yellow-100 text-yellow-800"
                              }
                            >
                              {match.result}
                            </Badge>
                          </TableCell>
                          <TableCell>{match.goals}</TableCell>
                          <TableCell>{new Date(match.date).toLocaleDateString()}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center">
                          No match history available
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        <Dialog open={editModalOpen} onOpenChange={setEditModalOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Profile</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {/* <Input placeholder="Name" value={updatedProfile.name} onChange={(e) => setUpdatedProfile({ ...updatedProfile, name: e.target.value })} />
            <Input placeholder="Phone" value={updatedProfile.phone} onChange={(e) => setUpdatedProfile({ ...updatedProfile, phone: e.target.value })} /> */}
              <Input
                placeholder="Position"
                value={updatedProfile.position}
                onChange={(e) => setUpdatedProfile({ ...updatedProfile, position: e.target.value })}
              />
              <Input
                placeholder="Team"
                value={updatedProfile.team}
                onChange={(e) => setUpdatedProfile({ ...updatedProfile, team: e.target.value })}
              />
              <Input
                placeholder="Jersey Number"
                type="number"
                value={updatedProfile.jersey_number}
                onChange={(e) => setUpdatedProfile({ ...updatedProfile, jersey_number: Number(e.target.value) })}
              />
              <Input
                placeholder="Age"
                type="number"
                value={updatedProfile.age}
                onChange={(e) => setUpdatedProfile({ ...updatedProfile, age: Number(e.target.value) })}
              />
              <Input
                placeholder="Nationality"
                value={updatedProfile.nationality}
                onChange={(e) => setUpdatedProfile({ ...updatedProfile, nationality: e.target.value })}
              />
              <Input
                placeholder="Joined Date"
                type="Date"
                value={updatedProfile.joined_date}
                onChange={(e) => setUpdatedProfile({ ...updatedProfile, joined_date: e.target.value })}
              />
            </div>
            <DialogFooter>
              <Button onClick={handleUpdateProfile}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}


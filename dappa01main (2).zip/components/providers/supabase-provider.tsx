"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import { createClient } from "@supabase/supabase-js"
import { useToast } from "@/components/ui/use-toast"

type SupabaseContextType = {
  supabase: any
  user: any
  loading: boolean
}

const SupabaseContext = createContext<SupabaseContextType>({
  supabase: null,
  user: null,
  loading: true,
})

export function SupabaseProvider({ children }: { children: React.ReactNode }) {
  const [supabaseClient, setSupabaseClient] = useState<any>(null)
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
    if (!supabaseUrl || !supabaseKey) {
      toast({
        title: "Supabase configuration error",
        description:
          "Please ensure NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY environment variables are set.",
        variant: "destructive",
      })
      setLoading(false)
      return
    }

    const supabase = createClient(supabaseUrl, supabaseKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    })

    const client = createClient(supabaseUrl, supabaseKey)
    setSupabaseClient(client)

    // Get initial session
    const initializeAuth = async () => {
      try {
        const {
          data: { session },
        } = await client.auth.getSession()
        setUser(session?.user || null)
      } catch (error) {
        console.error("Error getting session:", error)
      } finally {
        setLoading(false)
      }
    }

    // Always initialize auth session check
    initializeAuth()

    // Set up auth state change listener
    const {
      data: { subscription },
    } = client.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null)
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [toast])

  return (
    <SupabaseContext.Provider value={{ supabase: supabaseClient, user, loading }}>{children}</SupabaseContext.Provider>
  )
}

export function useSupabase() {
  return useContext(SupabaseContext)
}


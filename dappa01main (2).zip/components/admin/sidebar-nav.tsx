"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Trophy, Users, Calendar, LogOut, UserCheck, Activity, Menu, X } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { useSupabase } from "@/components/providers/supabase-provider"
import { useRouter } from "next/navigation"
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader } from "@/components/ui/sidebar"
import { useState, useEffect } from "react"

interface SidebarNavProps {
  className?: string
}

export function AdminSidebarNav({ className }: SidebarNavProps) {
  const pathname = usePathname()
  const { supabase } = useSupabase()
  const router = useRouter()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    // Check if we're on the client side
    if (typeof window !== "undefined") {
      const checkIfMobile = () => {
        setIsMobile(window.innerWidth < 768)
      }

      // Initial check
      checkIfMobile()

      // Add event listener for window resize
      window.addEventListener("resize", checkIfMobile)

      // Cleanup
      return () => window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/login")
  }

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen)
  }

  const navItems = [
    {
      title: "Dashboard",
      href: "/admin/dashboard",
      icon: Home,
    },
    {
      title: "Player Approvals",
      href: "/admin/dashboard/approvals",
      icon: UserCheck,
    },
    {
      title: "Players",
      href: "/admin/dashboard/players",
      icon: Users,
    },
    {
      title: "Tournaments",
      href: "/admin/dashboard/tournaments",
      icon: Trophy,
    },
    {
      title: "Matches",
      href: "/admin/dashboard/matches",
      icon: Calendar,
    },
    {
      title: "Live Updates",
      href: "/admin/dashboard/live",
      icon: Activity,
    },
    // {
    //   title: "Settings",
    //   href: "/admin/dashboard/settings",
    //   icon: Settings,
    // },
  ]

  // Mobile menu component
  const MobileMenu = () => (
    <div className="md:hidden fixed top-0 left-0 w-full h-full z-50">
      <div className="absolute inset-0 bg-black/50" onClick={toggleMobileMenu} />
      <div className="absolute top-0 left-0 w-64 h-full bg-background shadow-lg transform transition-transform duration-300 ease-in-out">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-2">
            <Trophy className="h-6 w-6" />
            <span className="text-lg font-bold">FCMS Admin</span>
          </div>
          <Button variant="ghost" size="icon" onClick={toggleMobileMenu}>
            <X className="h-5 w-5" />
          </Button>
        </div>
        <div className="p-4">
          <nav className="grid gap-2">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground",
                  pathname === item.href ? "bg-accent text-accent-foreground" : "transparent",
                )}
                onClick={toggleMobileMenu}
              >
                <item.icon className="h-4 w-4" />
                <span>{item.title}</span>
              </Link>
            ))}
          </nav>
        </div>
        <div className="absolute bottom-0 left-0 w-full p-4 border-t">
          <Button variant="ghost" className="w-full justify-start px-3" onClick={handleLogout}>
            <LogOut className="mr-2 h-4 w-4" />
            <span>Log out</span>
          </Button>
        </div>
      </div>
    </div>
  )

  return (
    <>
      {/* Mobile menu toggle button */}
      <div className="md:hidden fixed top-4 left-4 z-40">
        <Button variant="outline" size="icon" onClick={toggleMobileMenu}>
          <Menu className="h-5 w-5" />
        </Button>
      </div>

      {/* Mobile menu */}
      {isMobileMenuOpen && <MobileMenu />}

      {/* Desktop sidebar */}
      <div className="hidden md:block">
        <Sidebar>
          <SidebarHeader className="border-b pb-2">
            <div className="flex items-center gap-2 px-2">
              <Trophy className="h-6 w-6" />
              <span className="text-lg font-bold">FCMS Admin</span>
            </div>
          </SidebarHeader>
          <SidebarContent>
            <nav className="grid gap-1 px-2 group-[[data-collapsed=true]]:justify-center">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground",
                    pathname === item.href ? "bg-accent text-accent-foreground" : "transparent",
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  <span>{item.title}</span>
                </Link>
              ))}
            </nav>
          </SidebarContent>
          <SidebarFooter className="border-t pt-2">
            <Button variant="ghost" className="w-full justify-start px-3" onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" />
              <span>Log out</span>
            </Button>
          </SidebarFooter>
        </Sidebar>
      </div>
    </>
  )
}


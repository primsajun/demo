"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useSupabase } from "@/components/providers/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { Activity, Calendar, MapPin } from "lucide-react"

interface Match {
  id: string
  team_a: string
  team_b: string
  date: string
  time: string
  venue: string
  tournament_id: string
  tournaments: {
    name: string
  } | null
  score_team_a: number | null
  score_team_b: number | null
  status: string
}

interface MatchEvent {
  id: string
  match_id: string
  player_id: string
  player_name: string
  event_type: string
  minute: number
  timestamp: string
}

export default function PlayerLiveUpdatesPage() {
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [liveMatches, setLiveMatches] = useState<Match[]>([])
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null)
  const [matchEvents, setMatchEvents] = useState<MatchEvent[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchLiveMatches()

    // Set up real-time subscription for match updates
    const matchesSubscription = supabase
      .channel("public:matches")
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "matches",
          filter: "status=eq.live",
        },
        (payload) => {
          fetchLiveMatches()
        },
      )
      .subscribe()

    // Set up real-time subscription for match events
    const eventsSubscription = supabase
      .channel("public:match_events")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "match_events",
        },
        (payload) => {
          if (selectedMatch && payload.new.match_id === selectedMatch.id) {
            fetchMatchEvents(selectedMatch.id)
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(matchesSubscription)
      supabase.removeChannel(eventsSubscription)
    }
  }, [selectedMatch])

  const fetchLiveMatches = async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from("matches")
        .select(`
          *,
          tournaments(name)
        `)
        .eq("status", "live")
        .order("date", { ascending: true })

      if (error) {
        throw error
      }

      setLiveMatches(data || [])

      // If we have live matches and no selected match, select the first one
      if (data && data.length > 0 && !selectedMatch) {
        setSelectedMatch(data[0])
        fetchMatchEvents(data[0].id)
      }
    } catch (error: any) {
      console.error("Error fetching live matches:", error)
      toast({
        title: "Error fetching live matches",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const fetchMatchEvents = async (matchId: string) => {
    try {
      const { data, error } = await supabase
        .from("match_events")
        .select("*")
        .eq("match_id", matchId)
        .order("minute", { ascending: true })

      if (error) {
        throw error
      }

      // Add player names to events (in a real app, you'd join with profiles table)
      const eventsWithNames = data.map((event) => ({
        ...event,
        player_name: "Player Name", // This would come from a join in a real app
      }))

      setMatchEvents(eventsWithNames || [])
    } catch (error: any) {
      console.error("Error fetching match events:", error)
      toast({
        title: "Error fetching match events",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const handleSelectMatch = (match: Match) => {
    setSelectedMatch(match)
    fetchMatchEvents(match.id)
  }

  const getEventIcon = (eventType: string) => {
    switch (eventType) {
      case "goal":
        return "⚽"
      case "yellow-card":
        return "🟨"
      case "red-card":
        return "🟥"
      case "assist":
        return "👟"
      case "substitution":
        return "🔄"
      default:
        return "📝"
    }
  }

  const getEventLabel = (eventType: string) => {
    switch (eventType) {
      case "goal":
        return "Goal"
      case "yellow-card":
        return "Yellow Card"
      case "red-card":
        return "Red Card"
      case "assist":
        return "Assist"
      case "substitution":
        return "Substitution"
      default:
        return eventType
    }
  }

  if (loading && liveMatches.length === 0) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Live Updates</h1>

      {liveMatches.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6">
            <Activity className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-center text-muted-foreground">No live matches at the moment.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-3">
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Live Matches</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {liveMatches.map((match) => (
                  <div
                    key={match.id}
                    className={`rounded-md border p-3 cursor-pointer transition-colors ${
                      selectedMatch?.id === match.id ? "bg-primary/10 border-primary" : "hover:bg-muted"
                    }`}
                    onClick={() => handleSelectMatch(match)}
                  >
                    <div className="flex justify-between items-center mb-1">
                      <div className="font-medium">
                        {match.team_a} vs {match.team_b}
                      </div>
                      <Badge className="bg-red-100 text-red-800">LIVE</Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">{match.tournaments?.name || "Friendly Match"}</div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            {selectedMatch && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex justify-between items-center">
                    <span>
                      {selectedMatch.team_a} vs {selectedMatch.team_b}
                    </span>
                    <Badge className="bg-red-100 text-red-800">LIVE</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex justify-center items-center py-4">
                    <div className="text-center px-4">
                      <div className="text-2xl font-bold">{selectedMatch.team_a}</div>
                      <div className="text-5xl font-bold mt-2">{selectedMatch.score_team_a || 0}</div>
                    </div>
                    <div className="text-2xl font-bold px-4">-</div>
                    <div className="text-center px-4">
                      <div className="text-2xl font-bold">{selectedMatch.team_b}</div>
                      <div className="text-5xl font-bold mt-2">{selectedMatch.score_team_b || 0}</div>
                    </div>
                  </div>

                  <div className="flex justify-between text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      <span>
                        {new Date(selectedMatch.date).toLocaleDateString()} {selectedMatch.time}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      <span>{selectedMatch.venue || "N/A"}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-medium">Match Events</h3>
                    <div className="space-y-2 max-h-[300px] overflow-y-auto">
                      {matchEvents.length > 0 ? (
                        matchEvents.map((event) => (
                          <div key={event.id} className="flex items-center justify-between border-b pb-2">
                            <div className="flex items-center">
                              <div className="w-8 text-center font-medium">{event.minute}'</div>
                              <div className="w-8 text-center text-xl">{getEventIcon(event.event_type)}</div>
                              <div className="ml-2">
                                <div className="font-medium">{event.player_name}</div>
                                <div className="text-xs text-muted-foreground">{getEventLabel(event.event_type)}</div>
                              </div>
                            </div>
                            <div className="text-sm">
                              {event.event_type === "goal" ? (
                                <Badge className="bg-green-100 text-green-800">GOAL</Badge>
                              ) : event.event_type === "yellow-card" ? (
                                <Badge className="bg-yellow-100 text-yellow-800">YELLOW</Badge>
                              ) : event.event_type === "red-card" ? (
                                <Badge className="bg-red-100 text-red-800">RED</Badge>
                              ) : null}
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-center text-muted-foreground py-4">No events recorded yet</div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

